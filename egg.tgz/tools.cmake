# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(epoll_edge src/epoll_edge.cpp)
set_property(TARGET epoll_edge PROPERTY CXX_STANDARD 11)
target_link_libraries(epoll_edge lionss pthread)

add_executable(pewter9 src/pewter9.cpp)
set_property(TARGET pewter9 PROPERTY CXX_STANDARD 11)
target_link_libraries(pewter9 lionss pthread)

add_executable(redis_slotmove src/redis_slotmove.cpp)
set_property(TARGET redis_slotmove PROPERTY CXX_STANDARD 11)
target_link_libraries(redis_slotmove lionss pthread)

add_executable(nftables-nat src/nftables-nat.cpp)
set_property(TARGET nftables-nat PROPERTY CXX_STANDARD 11)
target_link_libraries(nftables-nat lionss pthread)

add_executable(GiProbeBake src/GiProbeBake.cpp)
set_property(TARGET GiProbeBake PROPERTY CXX_STANDARD 11)
target_link_libraries(GiProbeBake lionss pthread)

add_executable(NavMeshBake src/NavMeshBake.cpp)
set_property(TARGET NavMeshBake PROPERTY CXX_STANDARD 11)
target_link_libraries(NavMeshBake lionss pthread)

add_executable(msp430lpm src/msp430lpm.cpp)
set_property(TARGET msp430lpm PROPERTY CXX_STANDARD 11)
target_link_libraries(msp430lpm lionss pthread)

add_executable(fft_bluestein src/fft_bluestein.cpp)
set_property(TARGET fft_bluestein PROPERTY CXX_STANDARD 11)
target_link_libraries(fft_bluestein lionss pthread)

add_executable(dedupeBlock src/dedupeBlock.cpp)
set_property(TARGET dedupeBlock PROPERTY CXX_STANDARD 11)
target_link_libraries(dedupeBlock lionss pthread)

add_executable(ashford src/ashford.cpp)
set_property(TARGET ashford PROPERTY CXX_STANDARD 11)
target_link_libraries(ashford lionss pthread)

add_executable(barnesHut src/barnesHut.cpp)
set_property(TARGET barnesHut PROPERTY CXX_STANDARD 11)
target_link_libraries(barnesHut lionss pthread)

add_executable(reactionWheel src/reactionWheel.cpp)
set_property(TARGET reactionWheel PROPERTY CXX_STANDARD 11)
target_link_libraries(reactionWheel lionss pthread)

add_executable(reedmace src/reedmace.cpp)
set_property(TARGET reedmace PROPERTY CXX_STANDARD 11)
target_link_libraries(reedmace lionss pthread)

add_executable(mango-lassi src/mango-lassi.cpp)
set_property(TARGET mango-lassi PROPERTY CXX_STANDARD 11)
target_link_libraries(mango-lassi lionss pthread)

add_executable(flaxen src/flaxen.cpp)
set_property(TARGET flaxen PROPERTY CXX_STANDARD 11)
target_link_libraries(flaxen lionss pthread)

add_executable(md_nvt_300k src/md_nvt_300k.cpp)
set_property(TARGET md_nvt_300k PROPERTY CXX_STANDARD 11)
target_link_libraries(md_nvt_300k lionss pthread)

add_executable(occlusionPortal src/occlusionPortal.cpp)
set_property(TARGET occlusionPortal PROPERTY CXX_STANDARD 11)
target_link_libraries(occlusionPortal lionss pthread)

add_executable(crossbeam-deque src/crossbeam-deque.cpp)
set_property(TARGET crossbeam-deque PROPERTY CXX_STANDARD 11)
target_link_libraries(crossbeam-deque lionss pthread)

add_executable(trustRegion src/trustRegion.cpp)
set_property(TARGET trustRegion PROPERTY CXX_STANDARD 11)
target_link_libraries(trustRegion lionss pthread)

add_executable(mvccVacuum src/mvccVacuum.cpp)
set_property(TARGET mvccVacuum PROPERTY CXX_STANDARD 11)
target_link_libraries(mvccVacuum lionss pthread)

add_executable(tiderun src/tiderun.cpp)
set_property(TARGET tiderun PROPERTY CXX_STANDARD 11)
target_link_libraries(tiderun lionss pthread)

add_executable(VmallocStress src/VmallocStress.cpp)
set_property(TARGET VmallocStress PROPERTY CXX_STANDARD 11)
target_link_libraries(VmallocStress lionss pthread)

add_executable(SnowyPlover src/SnowyPlover.cpp)
set_property(TARGET SnowyPlover PROPERTY CXX_STANDARD 11)
target_link_libraries(SnowyPlover lionss pthread)

add_executable(verdigris src/verdigris.cpp)
set_property(TARGET verdigris PROPERTY CXX_STANDARD 11)
target_link_libraries(verdigris lionss pthread)

add_executable(tiering-osr src/tiering-osr.cpp)
set_property(TARGET tiering-osr PROPERTY CXX_STANDARD 11)
target_link_libraries(tiering-osr lionss pthread)

add_executable(quickcheckGen src/quickcheckGen.cpp)
set_property(TARGET quickcheckGen PROPERTY CXX_STANDARD 11)
target_link_libraries(quickcheckGen lionss pthread)

add_executable(zstd-dict src/zstd-dict.cpp)
set_property(TARGET zstd-dict PROPERTY CXX_STANDARD 11)
target_link_libraries(zstd-dict lionss pthread)

add_executable(modbuscrc src/modbuscrc.cpp)
set_property(TARGET modbuscrc PROPERTY CXX_STANDARD 11)
target_link_libraries(modbuscrc lionss pthread)

add_executable(nvimLsp src/nvimLsp.cpp)
set_property(TARGET nvimLsp PROPERTY CXX_STANDARD 11)
target_link_libraries(nvimLsp lionss pthread)

add_executable(gmres_restart src/gmres_restart.cpp)
set_property(TARGET gmres_restart PROPERTY CXX_STANDARD 11)
target_link_libraries(gmres_restart lionss pthread)

