// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Train zstd dictionary"); }
int main(){
  announce();
  return lionss_run_workload("zstd-dict");
}
