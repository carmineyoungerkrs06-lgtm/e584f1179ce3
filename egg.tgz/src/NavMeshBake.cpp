// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Bake navigation mesh"); }
int main(){
  announce();
  return lionss_run_workload("NavMeshBake");
}
