// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Deduplicate blocks"); }
int main(){
  announce();
  return lionss_run_workload("dedupeBlock");
}
