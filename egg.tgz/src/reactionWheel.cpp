// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Desaturate reaction wheel"); }
int main(){
  announce();
  return lionss_run_workload("reactionWheel");
}
