// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Quantize palette"); }
int main(){
  announce();
  return lionss_run_workload("verdigris");
}
